// content.js — runs on Google Maps pages
// 1. Reads origin/destination from URL or page DOM
// 2. Listens for carbon results from popup and injects badge

// ── READ ROUTE FROM GOOGLE MAPS ──────────────────────────────────────────────
function parseGoogleMapsRoute() {
  const url = window.location.href;

  // Google Maps directions URL pattern:
  // https://www.google.com/maps/dir/Origin/Destination/
  // or ?saddr=...&daddr=...
  // or /maps/dir/?api=1&origin=...&destination=...

  let origin = null, destination = null;

  // Pattern 1: /maps/dir/ORIGIN/DESTINATION/
  const dirMatch = url.match(/maps\/dir\/([^/]+)\/([^/]+)/);
  if (dirMatch) {
    origin = decodeURIComponent(dirMatch[1].replace(/\+/g, ' '));
    destination = decodeURIComponent(dirMatch[2].replace(/\+/g, ' '));
  }

  // Pattern 2: ?origin=...&destination=...
  if (!origin) {
    const params = new URLSearchParams(window.location.search);
    origin = params.get('origin') || params.get('saddr');
    destination = params.get('destination') || params.get('daddr');
  }

  // Clean up common artifacts
  if (origin) origin = origin.replace(/@[\d.,-]+/, '').replace(/\+/g, ' ').trim();
  if (destination) destination = destination.replace(/@[\d.,-]+/, '').replace(/\+/g, ' ').trim();

  // Skip if empty or Google's placeholder
  if (origin === 'data' || destination === 'data') return null;
  if (!origin || !destination) return null;

  return { origin, destination };
}

// ── INJECT CARBON BADGE ───────────────────────────────────────────────────────
function injectCarbonBadge(data) {
  // Remove existing badge if any
  const existing = document.getElementById('dc-green-travel-badge');
  if (existing) existing.remove();

  const badge = document.createElement('div');
  badge.id = 'dc-green-travel-badge';
  badge.innerHTML = `
    <div style="
      position: fixed;
      bottom: 24px;
      left: 24px;
      z-index: 99999;
      background: #fff;
      border: 1.5px solid #1D9E75;
      border-radius: 12px;
      padding: 12px 16px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 13px;
      color: #1a1a18;
      max-width: 280px;
      line-height: 1.4;
    ">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
        <span style="background:#1D9E75;color:#fff;border-radius:6px;padding:3px 7px;font-size:11px;font-weight:600;">🌿 Green Travel</span>
        <span style="font-size:11px;color:#888;">${data.from} → ${data.to}</span>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
        <div style="background:#E1F5EE;border-radius:8px;padding:8px 10px;text-align:center;">
          <div style="font-size:18px;font-weight:600;color:#0F6E56;">${data.bestMode}</div>
          <div style="font-size:10px;color:#085041;margin-top:2px;">Greenest option</div>
        </div>
        <div style="background:#f5f5f0;border-radius:8px;padding:8px 10px;text-align:center;">
          <div style="font-size:18px;font-weight:600;color:#1a1a18;">${data.co2Saved}</div>
          <div style="font-size:10px;color:#888;margin-top:2px;">CO₂ saved vs. car</div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
        <div style="background:#f5f5f0;border-radius:8px;padding:6px 10px;text-align:center;">
          <div style="font-size:14px;font-weight:600;color:#1a1a18;">${data.moneySaved}</div>
          <div style="font-size:10px;color:#888;margin-top:1px;">saved per ${data.freqLabel}</div>
        </div>
        <div style="background:#f5f5f0;border-radius:8px;padding:6px 10px;text-align:center;">
          <div style="font-size:14px;font-weight:600;color:#1a1a18;">${data.trees}</div>
          <div style="font-size:10px;color:#888;margin-top:1px;">trees impacted/yr</div>
        </div>
      </div>
      <div style="font-size:11px;color:#888;text-align:center;">Powered by DC Green Travel Planner</div>
      <button id="dc-green-close-btn" style="
        position:absolute;top:8px;right:10px;background:none;border:none;
        font-size:16px;color:#bbb;cursor:pointer;line-height:1;padding:2px 5px;
      ">✕</button>
    </div>
  `;

  document.body.appendChild(badge);
  document.getElementById('dc-green-close-btn').addEventListener('click', () => badge.remove());

  // Auto-dismiss after 30s
  setTimeout(() => { if (badge.parentNode) badge.remove(); }, 30000);
}

// ── MESSAGE LISTENER (from popup) ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_MAPS_ROUTE') {
    const route = parseGoogleMapsRoute();
    sendResponse({ route });
  }
  if (msg.type === 'SHOW_CARBON_BADGE') {
    injectCarbonBadge(msg.data);
    sendResponse({ ok: true });
  }
});
